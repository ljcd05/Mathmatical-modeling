import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from sklearn.svm import SVR
import itertools
from tqdm import tqdm
import pickle

# 加载模型和标准化器
def load_model_info(file_path):
    """加载保存的模型和标准化器信息"""
    try:
        with open(file_path, 'rb') as f:
            model_info = pickle.load(f)
        print(f"成功加载模型信息")
        return model_info['models'], model_info['scalers']
    except Exception as e:
        print(f"加载模型信息失败: {e}")
        return None, None

# 读取已有的回归模型结果
def load_model_results(file_path):
    """读取已有的回归模型结果CSV文件"""
    try:
        data = pd.read_csv(file_path, encoding='utf-8-sig')
        print(f"成功读取模型结果，共{len(data)}行")
        return data
    except Exception as e:
        print(f"读取模型结果失败: {e}")
        return None

# 逆向推导自变量
def inverse_regression(models, scalers, target_values, constraints=None, steps=1000):
    """
    根据目标因变量值，逆向推导可能的自变量组合
    
    参数:
    models - 字典，包含每个因变量的SVR模型
    scalers - 字典，包含每个因变量的标准化器
    target_values - 字典，包含每个因变量的目标值范围
    constraints - 字典，包含自变量的约束条件
    steps - 整数，每个自变量的采样点数
    
    返回:
    符合条件的自变量组合及对应的因变量预测值
    """
    # 设置自变量的采样范围
    if constraints is None:
        constraints = {
            "自变量1": {"min": 0, "max": 100},
            "自变量2": {"min": 0, "max": 100}
        }
    
    # 创建自变量的网格采样点
    x1_values = np.linspace(constraints["自变量1"]["min"], constraints["自变量1"]["max"], steps)
    x2_values = np.linspace(constraints["自变量2"]["min"], constraints["自变量2"]["max"], steps)
    
    # 创建所有可能的自变量组合
    combinations = list(itertools.product(x1_values, x2_values))
    
    # 创建结果列表
    results = []
    
    print(f"正在评估{len(combinations)}个可能的自变量组合...")
    
    # 对每个组合进行评估
    for x1, x2 in tqdm(combinations):
        X_raw = np.array([[x1, x2]])
        predictions = {}
        is_valid = True
        
        # 对每个因变量进行预测
        for y_col, model in models.items():
            # 标准化输入
            X_scaled = scalers[y_col]['X'].transform(X_raw)
            
            # 预测
            y_pred_scaled = model.predict(X_scaled)
            
            # 反标准化输出
            y_pred = scalers[y_col]['y'].inverse_transform(y_pred_scaled.reshape(-1, 1)).ravel()[0]
            
            predictions[y_col] = y_pred
            
            # 检查是否满足目标值范围
            if y_col in target_values:
                target = target_values[y_col]
                if "min" in target and y_pred < target["min"]:
                    is_valid = False
                    break
                if "max" in target and y_pred > target["max"]:
                    is_valid = False
                    break
        
        # 如果满足所有条件，添加到结果中
        if is_valid:
            result = {"自变量1": x1, "自变量2": x2}
            result.update(predictions)
            results.append(result)
    
    # 转换为DataFrame
    if results:
        results_df = pd.DataFrame(results)
        print(f"找到{len(results_df)}个符合条件的自变量组合")
        return results_df
    else:
        print("未找到符合条件的自变量组合")
        return pd.DataFrame()

# 敏感性分析
def sensitivity_analysis(models, scalers, base_point, delta=0.1, relative=True):
    """
    对给定的基准点进行敏感性分析
    
    参数:
    models - 字典，包含每个因变量的SVR模型
    scalers - 字典，包含每个因变量的标准化器
    base_point - 字典，包含基准点的自变量值
    delta - 浮点数，变化量
    relative - 布尔值，是否使用相对变化
    
    返回:
    敏感性分析结果DataFrame
    """
    x1_base = base_point["自变量1"]
    x2_base = base_point["自变量2"]
    
    # 计算变化量
    if relative:
        x1_delta = x1_base * delta
        x2_delta = x2_base * delta
    else:
        x1_delta = delta
        x2_delta = delta
    
    # 基准点预测
    X_base_raw = np.array([[x1_base, x2_base]])
    base_predictions = {}
    
    for y_col, model in models.items():
        # 标准化输入
        X_base_scaled = scalers[y_col]['X'].transform(X_base_raw)
        
        # 预测
        y_pred_scaled = model.predict(X_base_scaled)
        
        # 反标准化输出
        y_pred = scalers[y_col]['y'].inverse_transform(y_pred_scaled.reshape(-1, 1)).ravel()[0]
        
        base_predictions[y_col] = y_pred
    
    # 变化点预测
    variations = [
        {"name": "自变量1增加", "X_raw": np.array([[x1_base + x1_delta, x2_base]])},
        {"name": "自变量1减少", "X_raw": np.array([[x1_base - x1_delta, x2_base]])},
        {"name": "自变量2增加", "X_raw": np.array([[x1_base, x2_base + x2_delta]])},
        {"name": "自变量2减少", "X_raw": np.array([[x1_base, x2_base - x2_delta]])}
    ]
    
    results = []
    
    # 计算每个变化点的预测值和敏感性
    for var in variations:
        result = {"变化": var["name"]}
        
        for y_col, model in models.items():
            # 标准化输入
            X_scaled = scalers[y_col]['X'].transform(var["X_raw"])
            
            # 预测
            y_pred_scaled = model.predict(X_scaled)
            
            # 反标准化输出
            y_pred = scalers[y_col]['y'].inverse_transform(y_pred_scaled.reshape(-1, 1)).ravel()[0]
            
            base_pred = base_predictions[y_col]
            
            # 计算绝对变化和相对变化
            abs_change = y_pred - base_pred
            rel_change = abs_change / base_pred if base_pred != 0 else 0
            
            result[f"{y_col}_预测值"] = y_pred
            result[f"{y_col}_绝对变化"] = abs_change
            result[f"{y_col}_相对变化%"] = rel_change * 100
            
        results.append(result)
    
    # 添加基准点
    base_result = {"变化": "基准点"}
    for y_col, pred in base_predictions.items():
        base_result[f"{y_col}_预测值"] = pred
        base_result[f"{y_col}_绝对变化"] = 0
        base_result[f"{y_col}_相对变化%"] = 0
    
    results.insert(0, base_result)
    
    return pd.DataFrame(results)

# 稳定性分析
def stability_analysis(models, scalers, base_point, variations=100, noise_level=0.05):
    """
    通过添加随机噪声进行稳定性分析
    
    参数:
    models - 字典，包含每个因变量的SVR模型
    scalers - 字典，包含每个因变量的标准化器
    base_point - 字典，包含基准点的自变量值
    variations - 整数，随机变化的次数
    noise_level - 浮点数，噪声水平（相对于基准值的比例）
    
    返回:
    稳定性分析结果，包括均值、标准差和变异系数
    """
    x1_base = base_point["自变量1"]
    x2_base = base_point["自变量2"]
    
    # 计算噪声范围
    x1_noise = x1_base * noise_level
    x2_noise = x2_base * noise_level
    
    # 存储所有预测结果
    all_predictions = {y_col: [] for y_col in models.keys()}
    
    # 生成随机变化点并预测
    for _ in range(variations):
        # 添加随机噪声
        x1 = x1_base + np.random.uniform(-x1_noise, x1_noise)
        x2 = x2_base + np.random.uniform(-x2_noise, x2_noise)
        
        X_raw = np.array([[x1, x2]])
        
        # 对每个因变量进行预测
        for y_col, model in models.items():
            # 标准化输入
            X_scaled = scalers[y_col]['X'].transform(X_raw)
            
            # 预测
            y_pred_scaled = model.predict(X_scaled)
            
            # 反标准化输出
            y_pred = scalers[y_col]['y'].inverse_transform(y_pred_scaled.reshape(-1, 1)).ravel()[0]
            
            all_predictions[y_col].append(y_pred)
    
    # 计算统计指标
    stats = {}
    for y_col, preds in all_predictions.items():
        mean_val = np.mean(preds)
        std_val = np.std(preds)
        cv = std_val / mean_val if mean_val != 0 else 0  # 变异系数
        
        stats[y_col] = {
            "均值": mean_val,
            "标准差": std_val,
            "变异系数": cv,
            "最小值": np.min(preds),
            "最大值": np.max(preds)
        }
    
    return pd.DataFrame(stats).T

# 判断是否达成目标
def evaluate_target_achievement(predictions, target_values):
    """
    判断预测值是否达成目标值
    
    参数:
    predictions - 字典，包含每个因变量的预测值
    target_values - 字典，包含每个因变量的目标值范围
    
    返回:
    达成情况的评估结果
    """
    results = {}
    overall_achievement = True
    
    for y_col, pred in predictions.items():
        if y_col in target_values:
            target = target_values[y_col]
            achievement = True
            reasons = []
            
            if "min" in target and pred < target["min"]:
                achievement = False
                reasons.append(f"低于最小值{target['min']}")
            
            if "max" in target and pred > target["max"]:
                achievement = False
                reasons.append(f"超过最大值{target['max']}")
            
            results[y_col] = {
                "预测值": pred,
                "达成目标": achievement,
                "原因": ", ".join(reasons) if not achievement else "达标"
            }
            
            if not achievement:
                overall_achievement = False
        else:
            results[y_col] = {
                "预测值": pred,
                "达成目标": "未设置目标",
                "原因": "未设置目标值"
            }
    
    results["总体达成"] = overall_achievement
    
    return results

# 可视化合格区域
def visualize_valid_region(results_df, x_cols, output_dir='plots'):
    """生成合格区域可视化图"""
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    if len(results_df) > 0:
        plt.figure(figsize=(10, 8))
        plt.scatter(results_df[x_cols[0]], results_df[x_cols[1]], alpha=0.5)
        plt.xlabel(x_cols[0])
        plt.ylabel(x_cols[1])
        plt.title('符合所有目标条件的自变量区域 (SVR)')
        plt.grid(True)
        
        # 保存图表
        plt.savefig(os.path.join(output_dir, 'svr_valid_region.png'), dpi=300)
        plt.close()
        
        print(f"合格区域可视化已保存到 {output_dir}/svr_valid_region.png")
    else:
        print("没有符合条件的数据点，无法生成可视化")

# 主函数
def main():
    # 配置参数
    model_info_file = "svr_model_info.pkl"  # 模型信息文件
    output_file = "svr_inverse_results.csv"  # 输出文件名
    
    # 自变量和因变量列名
    x_columns = ["自变量1", "自变量2"]
    y_columns = ["因变量1", "因变量2", "因变量3", "因变量4"]
    
    # 目标因变量值范围（合格标准）
    target_values = {
        "因变量1": {"min": 50, "max": 70},
        "因变量2": {"min": 20, "max": 40},
        "因变量3": {"min": 15, "max": 30},
        "因变量4": {"min": 5, "max": 15}
    }
    
    # 自变量约束条件
    