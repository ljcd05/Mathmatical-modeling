import pandas as pd
import numpy as np
from sklearn.svm import SVR
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error, explained_variance_score
import os
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler

# 读取Excel数据
def load_data(file_path):
    """读取Excel数据文件"""
    try:
        data = pd.read_excel(file_path)
        print(f"成功读取数据，共{len(data)}行")
        return data
    except Exception as e:
        print(f"读取数据失败: {e}")
        return None

# 构建SVR回归模型
def build_svr_models(data, x_cols, y_cols, test_size=0.2, do_grid_search=True):
    """构建多个SVR回归模型，每个因变量一个模型，并评估准确性"""
    models = {}
    results = {}
    metrics = {}
    scalers = {}  # 保存标准化器
    
    X = data[x_cols].values
    
    # 定义SVR参数网格
    param_grid = {
        'C': [0.1, 1, 10, 100],
        'gamma': ['scale', 'auto', 0.1, 0.01],
        'epsilon': [0.01, 0.1, 0.2]
    }
    
    for y_col in y_cols:
        y = data[y_col].values
        
        # 数据标准化
        scaler_X = StandardScaler()
        scaler_y = StandardScaler()
        
        # 划分训练集和测试集
        if test_size > 0:
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=42)
            
            # 标准化训练数据
            X_train_scaled = scaler_X.fit_transform(X_train)
            y_train_scaled = scaler_y.fit_transform(y_train.reshape(-1, 1)).ravel()
            
            # 标准化测试数据
            X_test_scaled = scaler_X.transform(X_test)
            
            # 网格搜索最佳参数
            if do_grid_search:
                print(f"为 {y_col} 执行网格搜索...")
                grid_search = GridSearchCV(
                    SVR(kernel='rbf'),
                    param_grid=param_grid,
                    cv=5,
                    scoring='neg_mean_squared_error',
                    verbose=0,
                    n_jobs=-1
                )
                grid_search.fit(X_train_scaled, y_train_scaled)
                best_params = grid_search.best_params_
                print(f"  最佳参数: {best_params}")
                
                # 使用最佳参数创建模型
                model = SVR(kernel='rbf', **best_params)
            else:
                # 使用默认参数
                model = SVR(kernel='rbf', C=10, gamma='scale', epsilon=0.1)
            
            # 训练模型
            model.fit(X_train_scaled, y_train_scaled)
            
            # 在测试集上评估
            y_test_pred_scaled = model.predict(X_test_scaled)
            y_test_pred = scaler_y.inverse_transform(y_test_pred_scaled.reshape(-1, 1)).ravel()
            
            # 计算评价指标
            r2 = r2_score(y_test, y_test_pred)
            rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
            mae = mean_absolute_error(y_test, y_test_pred)
            evs = explained_variance_score(y_test, y_test_pred)
            
            # 保存评价指标
            metrics[y_col] = {
                'r2_score': r2,
                'rmse': rmse,
                'mae': mae,
                'explained_variance': evs
            }
            
            print(f"模型 {y_col} 测试集评价:")
            print(f"  R² = {r2:.4f}")
            print(f"  RMSE = {rmse:.4f}")
            print(f"  MAE = {mae:.4f}")
            print(f"  解释方差比 = {evs:.4f}")
            
            # 在全部数据上重新拟合
            X_scaled = scaler_X.fit_transform(X)
            y_scaled = scaler_y.fit_transform(y.reshape(-1, 1)).ravel()
            
            if do_grid_search:
                model = SVR(kernel='rbf', **best_params)
            else:
                model = SVR(kernel='rbf', C=10, gamma='scale', epsilon=0.1)
                
            model.fit(X_scaled, y_scaled)
        else:
            # 标准化全部数据
            X_scaled = scaler_X.fit_transform(X)
            y_scaled = scaler_y.fit_transform(y.reshape(-1, 1)).ravel()
            
            # 网格搜索最佳参数
            if do_grid_search:
                print(f"为 {y_col} 执行网格搜索...")
                grid_search = GridSearchCV(
                    SVR(kernel='rbf'),
                    param_grid=param_grid,
                    cv=5,
                    scoring='neg_mean_squared_error',
                    verbose=0,
                    n_jobs=-1
                )
                grid_search.fit(X_scaled, y_scaled)
                best_params = grid_search.best_params_
                print(f"  最佳参数: {best_params}")
                
                # 使用最佳参数创建模型
                model = SVR(kernel='rbf', **best_params)
            else:
                # 使用默认参数
                model = SVR(kernel='rbf', C=10, gamma='scale', epsilon=0.1)
            
            # 训练模型
            model.fit(X_scaled, y_scaled)
            
            # 在训练数据上评估
            y_pred_scaled = model.predict(X_scaled)
            y_pred = scaler_y.inverse_transform(y_pred_scaled.reshape(-1, 1)).ravel()
            
            # 计算评价指标
            r2 = r2_score(y, y_pred)
            rmse = np.sqrt(mean_squared_error(y, y_pred))
            mae = mean_absolute_error(y, y_pred)
            evs = explained_variance_score(y, y_pred)
            
            # 保存评价指标
            metrics[y_col] = {
                'r2_score': r2,
                'rmse': rmse,
                'mae': mae,
                'explained_variance': evs
            }
            
            print(f"模型 {y_col} 全数据评价:")
            print(f"  R² = {r2:.4f}")
            print(f"  RMSE = {rmse:.4f}")
            print(f"  MAE = {mae:.4f}")
            print(f"  解释方差比 = {evs:.4f}")
        
        # 预测全部数据
        X_all_scaled = scaler_X.transform(X)
        y_pred_scaled = model.predict(X_all_scaled)
        y_pred = scaler_y.inverse_transform(y_pred_scaled.reshape(-1, 1)).ravel()
        
        # 保存模型、标准化器和结果
        models[y_col] = model
        scalers[y_col] = {'X': scaler_X, 'y': scaler_y}
        results[y_col] = {
            'predictions': y_pred,
            'support_vectors_ratio': len(model.support_) / len(X)
        }
        
        print(f"模型 {y_col}: 支持向量比例 = {results[y_col]['support_vectors_ratio']:.4f}")
    
    return models, results, metrics, scalers

# 保存结果到CSV
def save_results(data, results, metrics, x_cols, y_cols, output_file):
    """保存回归结果到CSV文件"""
    # 创建结果DataFrame
    result_df = data[x_cols].copy()
    
    # 添加原始因变量和预测值
    for y_col in y_cols:
        result_df[f"{y_col}_原始值"] = data[y_col]
        result_df[f"{y_col}_预测值"] = results[y_col]['predictions']
        result_df[f"{y_col}_残差"] = data[y_col] - results[y_col]['predictions']
    
    # 保存到CSV
    result_df.to_csv(output_file, index=False, encoding='utf-8-sig')
    print(f"结果已保存到 {output_file}")
    
    # 保存评价指标
    metrics_df = pd.DataFrame(metrics).T
    metrics_file = output_file.replace('.csv', '_metrics.csv')
    metrics_df.to_csv(metrics_file, encoding='utf-8-sig')
    print(f"评价指标已保存到 {metrics_file}")
    
    # 保存模型信息
    model_info = {}
    for y_col in y_cols:
        model_info[y_col] = {
            'support_vectors_ratio': results[y_col]['support_vectors_ratio']
        }
    
    model_info_df = pd.DataFrame(model_info).T
    model_info_file = output_file.replace('.csv', '_model_info.csv')
    model_info_df.to_csv(model_info_file, encoding='utf-8-sig')
    print(f"模型信息已保存到 {model_info_file}")
    
    return result_df

# 生成预测结果可视化
def visualize_results(data, results, y_cols, output_dir='plots'):
    """生成预测结果与实际值的对比图"""
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        
    for y_col in y_cols:
        plt.figure(figsize=(10, 6))
        plt.scatter(data[y_col], results[y_col]['predictions'], alpha=0.5)
        
        # 添加对角线（理想情况）
        min_val = min(data[y_col].min(), min(results[y_col]['predictions']))
        max_val = max(data[y_col].max(), max(results[y_col]['predictions']))
        plt.plot([min_val, max_val], [min_val, max_val], 'r--')
        
        plt.xlabel('实际值')
        plt.ylabel('预测值')
        plt.title(f'{y_col} - 预测值 vs 实际值 (SVR)')
        plt.grid(True)
        
        # 保存图表
        plt.savefig(os.path.join(output_dir, f'{y_col}_prediction_svr.png'), dpi=300)
        plt.close()
        
    print(f"可视化结果已保存到 {output_dir} 目录")

# 遴选系统
def filter_results(result_df, y_cols, criteria, output_file):
    """根据给定条件遴选结果"""
    filtered_df = result_df.copy()
    
    # 应用筛选条件
    for y_col, criterion in criteria.items():
        if y_col in y_cols:
            if 'min' in criterion:
                filtered_df = filtered_df[filtered_df[f"{y_col}_原始值"] >= criterion['min']]
            if 'max' in criterion:
                filtered_df = filtered_df[filtered_df[f"{y_col}_原始值"] <= criterion['max']]
            if 'abs_residual_max' in criterion:
                filtered_df = filtered_df[abs(filtered_df[f"{y_col}_残差"]) <= criterion['abs_residual_max']]
    
    # 保存筛选后的结果
    filtered_df.to_csv(output_file, index=False, encoding='utf-8-sig')
    print(f"筛选后的结果已保存到 {output_file}")
    print(f"筛选前数据量: {len(result_df)}, 筛选后数据量: {len(filtered_df)}")
    
    return filtered_df

# 保存模型和标准化器
def save_model_info(models, scalers, file_path):
    """保存模型信息到文件，用于后续逆向推导"""
    model_info = {
        'models': models,
        'scalers': scalers
    }
    
    import pickle
    with open(file_path, 'wb') as f:
        pickle.dump(model_info, f)
    
    print(f"模型和标准化器信息已保存到 {file_path}")

# 主函数
def main():
    # 配置参数
    input_file = "regression_data.xlsx"  # Excel文件名
    output_file = "svr_regression_results.csv"  # 输出文件名
    filtered_output_file = "svr_filtered_results.csv"  # 筛选后的输出文件名
    model_info_file = "svr_model_info.pkl"  # 模型信息文件
    
    # 自变量和因变量列名
    x_columns = ["自变量1", "自变量2"]  # 请替换为实际的列名
    y_columns = ["因变量1", "因变量2", "因变量3", "因变量4"]  # 请替换为实际的列名
    
    # 筛选条件
    filter_criteria = {
        "因变量1": {"min": 10, "max": 100, "abs_residual_max": 5},
        "因变量2": {"min": 0, "abs_residual_max": 10},
        "因变量3": {"max": 50},
        "因变量4": {"abs_residual_max": 8}
    }
    
    # 执行流程
    data = load_data(input_file)
    if data is not None:
        # 构建SVR模型
        models, results, metrics, scalers = build_svr_models(
            data, x_columns, y_columns, 
            test_size=0.2,
            do_grid_search=True  # 设置为False可以加快运行速度，但可能降低模型性能
        )
        
        # 保存结果
        result_df = save_results(data, results, metrics, x_columns, y_columns, output_file)
        
        # 可视化结果
        visualize_results(data, results, y_columns)
        
        # 遴选结果
        filtered_df = filter_results(result_df, y_columns, filter_criteria, filtered_output_file)
        
        # 保存模型信息，用于逆向推导
        save_model_info(models, scalers, model_info_file)

if __name__ == "__main__":
    main()